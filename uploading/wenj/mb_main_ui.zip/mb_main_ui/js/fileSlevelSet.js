/*
    1.定密单位的显示
    2.各种操作下元素的显示隐藏状态和编辑状态
    3.新加元素的赋值
    4.其他定密单位的选择和显示
    5.知悉范围人员的选择和显示
 */
var g_info = {
    version:'1.0.0.0',  //string,json版本
    ManageStatus:1,     //uint32_t,管理状态
    DefUnit:{
        Main  : { Id:1, Name:'' },
        Other : []
    },
    Drafter:{ Id:1, Name:'3123' },  //文件起草人
    Classifer:{ Id:1, Name:'3123' },//定密责任人
    Issuer:{ Id:1, Name:'12' },   //文件签发人
    SecDegree:undefined,        //uint32_t,秘密等级
    LimitTime:          //保密期限
    {
        DefTime:'',         //定密时间
        DefTimeStr:'',
        Type:0,// uint32_t,类型，见下面的定义
        Value:'20140901' // value, 根据不同的Type值，有不同的类型和含义
                 // Type=0(解密时间): string,YYYYMMDD
                 // Type=1(解密条件): string,描述至多50个汉字
    },
    LimitRange:      //知悉范围
    {
        Type:0,    // uint32_t,类型，见下面的定义
        Value:''   // Type=0(列举表示): vector:逐一列举文件可知悉的人员或单位，具体格式如下：[{SubType:,Name:}]
                   // Type=1(描述表示): string, 描述文件可知悉的人员或单位组成，不超过512byte
    },
    /*History:[
        {
            ModifyTime : "",   //修改时间，string
            OpUserID   : 123456, // 操作者id,uint32_t
            HisType    : 1,        // 0：修改秘密等级， 1：修改保密期限
            SecDegreeBefore: 0 ,// 变更前的秘密的等级，optional
            LimitTimeBefore:   // 变更前的保密期限，Optional
            {
                DefTime:"20140710100000",//string,定密时间,YYYYMMDDHHmmss
                Type:0,// uint32_t,类型，见下面的定义
                Value: ''// value, 根据不同的Type值，有不同的类型和含义
                         // Type=0(解密时间): string,YYYYMMDD
                         // Type=1(解密条件): string,描述至多50个汉字
            },
            HisDesc: "" // 描述，string,SIZE(1...255)
        }
    ],*/
    DefBasis:'',      //定密依据,字符串数组，每个字符串表示一个定密依据的代码
    IssueNumber: '', //文档号，string, SIZE(1...50)
    DocNumber: 0,  //份号
    OperationCtrl:{
        copy: 0, // 复制策略，0表示允许复制，1表示不允许复制
        paste:0, // 粘贴策略，0表示允许粘贴，1表示
        print:0
    }
},
    g_optType = 6,//1:查看密级; 2:设置密级; 3:修改密级; 4:正式定密 5:文件签发 6:文件解密 7:解除标志 8.查询统计 9.解密提醒
    g_userInfo = {
        unit:'',
        person:'',
        slevel:4
    },
    g_DefUnits = [],//[{Id:1,Name:'1'},{Id:2,Name:'2'},{Id:3,Name:'3'},{Id:4,Name:'4'}],
    g_StructInfo = [],//[{Id:0,Name:'公司',children:[{Id:5,Name:'部门2'},{Id:1,Name:'部门1',children:[{Id:2,Name:'用户1'},{Id:3,Name:'用户2'},{Id:4,Name:'用户3'}]}]}],
    g_Units = [],
    g_Users = [],
    g_pageSet = {},
    g_StructTree = null;

var ManageStatus    = ['','预定密','正式定密','文件签发','文件解密'],
    LimitTimeTypes  = ['解密时间','解密条件'],
    Slevels         = ['公开','内部','秘密','机密','绝密'],
    LimitRangeTypes = ['列举表示','描述表示'],
    LimitTimeDefault= { 2:10, 3:20, 4:30 };

var pagesSet = {
    1:{
        btns:[
            { label:'关闭', func:'close', cl:'btn-default' }
        ]
    },
    2:{
        btns:[
            { label:'确定', func:'setinfo', cl:'btn-primary' }
        ]
    },
    3:{
        btns:[
            { label:'确定', func:'setinfo', cl:'btn-primary' },
            { label:'取消', func:'close', cl:'btn-default' }
        ]
    },
    4:{
        btns:[
            { label:'定密', func:'setinfo', cl:'btn-primary' },
            { label:'取消', func:'close', cl:'btn-default' }
        ]
    },
    5:{
        btns:[
            { label:'签发', func:'setinfo', cl:'btn-primary' },
            { label:'取消', func:'close', cl:'btn-default' }
        ]
    },
    6:{
        btns:[
            { label:'解密', func:'setinfo', cl:'btn-primary' },
            { label:'取消', func:'close', cl:'btn-default' }
        ]
    }
};


// 对Date的扩展，将 Date 转化为指定格式的String
// 月(M)、日(d)、小时(h)、分(m)、秒(s)、季度(q) 可以用 1-2 个占位符， 
// 年(y)可以用 1-4 个占位符，毫秒(S)只能用 1 个占位符(是 1-3 位的数字) 
// 例子： // (new Date()).Format("yyyy-MM-dd hh:mm:ss.S") ==> 2006-07-02 08:09:04.423 
// (new Date()).Format("yyyy-M-d h:m:s.S")      ==> 2006-7-2 8:9:4.18 
Date.prototype.Format = function (fmt) {    
    var o = {       
        "M+": this.getMonth() + 1, //月份        
        "d+": this.getDate(), //日        
        "h+": this.getHours(), //小时        
        "m+": this.getMinutes(), //分        
        "s+": this.getSeconds(), //秒        
        "q+": Math.floor((this.getMonth() + 3) / 3), //季度        
        "S": this.getMilliseconds() //毫秒    
    };
    if (/(y+)/.test(fmt))
        fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));   

    for (var k in o)    
        if (new RegExp("(" + k + ")").test(fmt))
            fmt = fmt.replace(RegExp.$1,  (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" +  o[k]).length)));   
    return fmt;
};


/**
 * 获取信息
 */
function getInfos(){
    /**
     * 获取用户信息
     */
    function getUserInfo(){
        if( typeof JsObject != 'undefined' && JsObject.getUserInfo ){
            var _info = JsObject.getUserInfo();
            if( _info.error ) {
                alert(_info.error);
                return  false;
            }
            if( _info ) {
                $.extend(g_userInfo, _info);
            }
        }
    }

    /**
     * 获取文件信息
     */
    function getFileInfo(){
        if( typeof JsObject != 'undefined' && JsObject.getFileSlevelInfo ){
            var _info = JsObject.getFileSlevelInfo();
            if( _info.error ) {
                alert(_info.error);
                return  false;
            }
            if( _info )
                $.extend( g_info, _info );
        }
        if( g_info.DefTime && g_optType != 1 ) {
            if ( typeof g_info.DefTime == 'string' ){
                var _t = g_info.DefTime;
                g_info.DefTimeStr = _t.substr(0,4)+'-'+_t.substr(4,2)+'-'+_t.substr(6,2)+' '+_t.substr(8,2)+':'+_t.substr(10,2)+':'+_t.substr(12,2);
            } else {
                var d = new Date( g_info.DefTime * 1000 );
                g_info.DefTimeStr = d.Format('yyyy-MM-dd hh:mm:ss');
            }
        } else {
            var date = new Date();
            g_info.DefTime = date.Format('yyyyMMddhhmmss');
            g_info.DefTimeStr = date.Format('yyyy-MM-dd hh:mm:ss');
        }
    }

    /**
     * 获取当前页面操作码
     * @returns {boolean}
     */
    function getOptType(){
        if( typeof JsObject != 'undefined' && JsObject.getFileOptType ){
            var _type = JsObject.getFileOptType();
            if( _type.error ) {
                alert(_type.error);
                return  false;
            }
            if( _type )
                g_optType = _type;
        }

        if( pagesSet[g_optType] )
            g_pageSet = pagesSet[g_optType];
    }

    /**
     * 获取定密单位列表
     * @returns {boolean}
     */
    function getDefUnits(){
        if( typeof JsObject != 'undefined' && JsObject.getDefUnits ){
            var _units = JsObject.getDefUnits();
            if( _units.error ) {
                alert(_units.error);
                return  false;
            }
            if( _units )
                g_DefUnits = _units;
        }
    }

    /**
     * 获取组织架构信息
     * @returns {boolean}
     */
    function getStructInfo(){
        if( typeof JsObject != 'undefined' && JsObject.getStructInfo ){
            var _info = JsObject.getStructInfo();
            if( _info.error ) {
                alert(_info.error);
                return  false;
            }
            /*if( _info){
                g_Units = _info.units;
                g_Users = _info.users;
                g_StructInfo = userStructDataHandle( g_Units, g_Users, userDFill );
            }*/
            if( _info )
                g_StructInfo = _info;
        }
    }

    getUserInfo();
    getDefUnits();
    getStructInfo();
    getOptType();
    getFileInfo();
}

function userDFill(data,fid){
    var tmp = {};
    if( !data )
        return	;
    tmp.Id = data.Id;
    tmp.parentid = fid;
    tmp.Name = data.Name;
    return tmp;
}

//将组织架构,用户 组装成树型数据
function userStructDataHandle(data,chdData,filldata){
    function getchldData(tdata){
        for(var key in chdData)
        {
            var d = chdData[key];
            if(chdData[key].pid == tdata.Id)
            {
                if(filldata)
                    tdata.children.push(filldata(d,tdata.Id));
            }
        }
    }

    function RecurFunc(tempData){
        var parentId;
        if(tempData == undefined)
        {
            parentId = '0';
            tempData = [];
        } else {
            parentId = tempData.id;
        }
        for(key in data)
        {
            var tdata = {};
            if(data[key].parentid == parentId)
            {
                tdata.Id = data[key].Id;
                tdata.Name = data[key].Name;
                tdata.childid = data[key].childid;
                tdata.parentid = parentId;
                tdata.children = [];
                RecurFunc(tdata);
                getchldData(tdata);
                tempData.push(tdata);
            }
        }
        return tempData;
    }
    var rawdata = {
        identifier: 'Id',
        label: 'Name',
        items: []
    };

    return RecurFunc();
}

function getUserName(uid)
{
    var userData = g_Users;
    for(var k in userData)
    {
        if(userData[k].Id == uid)
            return userData[k].Name;
    }

    var struct = g_Units;
    for(var k in struct)
    {
        if(struct[k].Id == uid)
            return struct[k].Name;
    }
    return	'';
}

function bldUSearch( args ){
    if(!args.input || typeof(args.input) != 'object' || !args.tree)
        return	;
    var search_input = args.input;
    var search_tree  = args.tree;
    var search_btn   = args.btn;
    var search_con   = args.con;
    var search_list  = args.list;
    var search_fields= null;

    if(args.fields && args.fields.length)
        search_fields = args.fields;

    function bldcon() {
        return  ;
    }

    search_input.keyup(function(event){
        userTreeGridSearch(event);
    })
        .keydown(function(event) {
            $bigAutocompleteContent = search_con;
            switch (event.keyCode) {
                case 40://向下键
                    if(!$bigAutocompleteContent || $bigAutocompleteContent.is(":visible") == false)return;
                    var $nextSiblingTr = $bigAutocompleteContent.find(".active");
                    if($nextSiblingTr.length <= 0){//没有选中行时，选中第一行
                        $nextSiblingTr = $bigAutocompleteContent.find("li:first");
                    }else{
                        $nextSiblingTr = $nextSiblingTr.next();
                    }
                    $bigAutocompleteContent.find("li").removeClass("active");

                    if($nextSiblingTr.length > 0){//有下一行时（不是最后一行）
                        $nextSiblingTr.addClass("active");//选中的行加背景
                        //$this.val($nextSiblingTr.find("div:last").html());//选中行内容设置到输入框中

                        //div滚动到选中的行,jquery-1.6.1 $nextSiblingTr.offset().top 有bug，数值有问题
                        var sh = $nextSiblingTr[0].offsetTop - $bigAutocompleteContent.height() + $nextSiblingTr.height();
                        $bigAutocompleteContent.scrollTop(sh);

                    }else{
                        //$this.val(bigAutocomplete.holdText);//输入框显示用户原始输入的值
                    }


                    break;
                case 38://向上键
                    if(!$bigAutocompleteContent || $bigAutocompleteContent.is(":visible") == false)return;
                    var $previousSiblingTr = $bigAutocompleteContent.find(".active");
                    if($previousSiblingTr.length <= 0){//没有选中行时，选中最后一行行
                        $previousSiblingTr = $bigAutocompleteContent.find("li:last");
                    }else{
                        $previousSiblingTr = $previousSiblingTr.prev();
                    }
                    $bigAutocompleteContent.find("li").removeClass("active");

                    if($previousSiblingTr.length > 0){//有上一行时（不是第一行）
                        $previousSiblingTr.addClass("active");//选中的行加背景
                        var sh = $previousSiblingTr[0].offsetTop - $bigAutocompleteContent.height() + $previousSiblingTr.height();
                        $bigAutocompleteContent.scrollTop(sh);
                    }

                    break;
                case 27://ESC键隐藏下拉框
                    emptySearchContent();
                    break;
                case 13:
                    if(!$bigAutocompleteContent ||$bigAutocompleteContent.is(":visible") == false)
                        return	sa_search();
                    var sel_it = $(".active",$bigAutocompleteContent);
                    if(sel_it)
                        var data = sel_it.data('rowInfo');
                    if(data)
                    {
                        search_input.val(data.uname);
                        search_con.hide();
                        search_tree.collapseAll();
                        goToTreeGridItem(data);
                    }
                    break;
            }
        });

    $(document).not(search_input).click(function(e){
        var t = $(e.target);
        if(t.hasClass('sa_starts'))
            return	;
        emptySearchContent();
    });

    search_btn.click(function(){
        sa_search();
    });

    function matchSFields(it,val) {
        if(!search_fields || !it || !val)
            return	false;
        for(var i in search_fields)
        {
            if(it[search_fields[i]] && it[search_fields[i]].toLowerCase().indexOf(val.toLowerCase()) != -1)
                return	true;
        }
        return	false;
    }

    function getTreeGridItemsByName(val)
    {
        var depart = [] , valfield ;
        if(!val || typeof val != 'string'|| val == '')
            return	[];
        valfield = search_tree.options.textFieldName;
        for(var x in search_tree.nodes)
        {
            var it = search_tree.nodes[x];
            if((it[valfield] && it[valfield].toLowerCase().indexOf(val.toLowerCase()) != -1) ||
                matchSFields(it,val) == true
                )
            {
                var p = search_tree.getParent(it);
                depart.push({uname:it[valfield],id:it.Id,fname:p?p[valfield]:''});
            }
        }
        return	depart;
    }

    function goToTreeGridItem(itdata){
        if(!itdata || !itdata.id)
            return	;
        var node = search_tree.getNodedomByID(itdata.id);
        if(node)
        {
            search_tree.upExpandTreeNode(node);
            search_tree.selectNode(node);
            setTimeout(function(){$(search_tree.element).scrollTop(node[0].offsetTop);},300);
        }
    }

    function	emptySearchContent(){
        if(search_list)
        {
            $('li',search_list).each(function(){
                $(this).removeData('rowInfo').removeData('dindex');
            });
            search_list.empty();
        }
        if( search_con ){
            search_con.hide();
        }
    }

    function sa_search(){
        var sword = search_input.val().toLowerCase();
        if(sword == '')
            return	emptySearchContent();
        var res = getTreeGridItemsByName($.trim(sword));
        bldcon();
        //emptySearchContent();
        if(res.length == 0)
            return	search_list.html('<div style="text-align:center;">没有找到匹配结果</div>');
        search_list.show().empty();
        search_con.show().position({
            my: "left top",
            at: "left bottom",
            of: search_input
        });
        for(var k in res)
        {
            var it = res[k];
            $('<li><a href="javascript:void(0);">'+it.uname+'('+it.fname+')</a></li>').appendTo(search_list).data('rowInfo',res[k]).click(function(){
                var data = $(this).data('rowInfo');
                search_input.val(data.uname);
                emptySearchContent();
                goToTreeGridItem(data);
            })
                .mouseover(function(){
                    $(this).addClass('selected').siblings('.selected').removeClass('selected');
                })
                .mouseout(function(){
                    $(this).removeClass('selected');
                });
        }
    }

    function userTreeGridSearch(e){
        e = window.event || e;
        var code = e.keyCode || e.which;
        var newcode = String.fromCharCode(code);
        var validKey = [
         8,        // backspace
         9,        // tab
         13,       // enter
         27,       // escape
         35,       // end
         36,       // home
         37,       // left arrow
         39,       // right arrow
         46,       // delete
         110, 190  // period
         ];
        var validKey = [9,20,13,16,17,18,91,92,93,45,36,33,34,35,37,39,112,113,114,115,116,117,118,119,120,121,122,123,144,19,145,40,38,27];//键盘上功能键键值数组
        for (var i = 0, c; c = validKey[i]; i++) {
            if (code == c)
            {
                newcode = '';
                return	;
            }
        }

        sa_search();
    }
}

function showSetRange(){
    $('.struct_wrap').show();

    if( !g_StructTree ){
        $("#struct_tree").ligerTree({
            data:g_StructInfo,
            checkbox: true,
            textFieldName: 'Name',
            idFieldName: 'Id',
            parentIcon: 'groupIcon',
            childIcon: 'personIcon'
        });

        g_StructTree = $("#struct_tree").ligerGetTreeManager();
        $('.user_search_input').removeAttr('disabled');
        bldUSearch({input:$('.user_search_input'),tree:g_StructTree,btn:$('.struct_wrap .search_btn'),con:$('.struct_wrap .list-con'),list:$('.struct_wrap .search-container')});
    }
}

/**
 * 页面时间初始化
 */
function InitEvent(){
    var $lTimeTypeSet = $('.LimitTimeTypeSet'),
        $fSlevelSet = $('.fSlevelSel'),
        $lTimeNum = $('#LimitTimeNum'),
        $LimitRange = $('#LimitRange');

    //禁止选中
    document.onselectstart = function() { return false; };

    $('*').disableSelection(function( event ){
        var target = $(event.target), ret = true;
        if( target.is('input')   ||
            target.is('select')  ||
            target.is('textarea')||
            target.is('button'))
            ret = false;
        return ret;
    });

    //禁止右键菜单
    document.oncontextmenu = function() { return false; };

    //禁止拖拽
    document.ondragstart = function() { return false; };

    //禁止复制
    document.oncopy = function() { return false; };

    var unit_data = [],
        unit_sel_data = [];

    for( var u in g_DefUnits ){
        var unit = g_DefUnits[u];
        if( unit.Id )
            unit_data.push( {label: unit.Name, value: unit.Id} );
    }

    for( var u in g_info.DefUnit.Other ){
        var unit = g_info.DefUnit.Other[u];
        if( unit.Id )
            unit_sel_data.push( unit.Id );
    }

    $('.multiselect').multiselect({
        numberDisplayed:9999,
        nonSelectedText:'请选择其他定密单位',
        buttonTitle: function(options, select) {
            var selected = '';
            options.each(function () {
                selected += $(this).text() + ', ';
            });
            return selected.substr(0, selected.length - 2);
        },
        maxHeight:300,
        buttonWidth:400,
        enableFiltering:true,
        disableIfEmpty:true,
        filterBehavior:'both',
        enableCaseInsensitiveFiltering:true,
        filterPlaceholder:'搜索'
    }).multiselect('dataprovider', unit_data)
    .multiselect('select', unit_sel_data);

    $('.struct_ok').click(function(){
        var sel, _info = [], _range = '';

        if( !g_StructTree )
            return  ;
        sel = g_StructTree.getChecked( true);
        if( !sel.length ){
            alert('请选择推荐人！');
            return ;
        }
        for( var i in sel){
            var it = sel[i];
            _info.push( {Id:it.data.Id,SubType:(it.data.children)?0:1,Name:it.data.Name} );
            _range += it.data.Name + ', ';
        }
        g_info.LimitRange.Value = _info;
        $LimitRange.val( _range.substr(0, _range.length-2) );
        $('.struct_wrap').hide();
    });

    $('.struct_canel').click(function(){
        $('.struct_wrap').hide();
    });

    $('.optbtn').click(function(){
        var func = $(this).attr('func');
        if( !func )
            return  ;
        try{
            eval( func+'();');
        } catch (err){
        }
    });

    if( g_optType != 1 ){
        $lTimeNum.datepicker({
            dateFormat:'yy-mm-dd',
            changeYear:true,
            yearRange: 'c-10:c+30',
            minDate: new Date(),
            beforeShow:function(){
                var t = $lTimeTypeSet.val();
                if( t != 0 )
                    return false;
            }
        }).unbind('keypress').unbind('keyup')
            .keypress(function( event ){
                var _type = $lTimeTypeSet.val();
                if( _type == 0 ) {
                    return  false;
                } else {
                    return  true;
                }
            });
    }

    $fSlevelSet.change(function(){
        var lttype = $lTimeTypeSet.val(),
            _slevel = $(this).val(),
            _max = null;
        if( lttype == 0 )
            $lTimeNum.val('');

        if( LimitTimeDefault[_slevel] )
            _max = '+'+LimitTimeDefault[_slevel]+'Y';

        $lTimeNum.datepicker({maxDate: _max});
    });

    $lTimeTypeSet.change(function(){
        var lttype = parseInt($(this).val()),
            $num = $('#LimitTimeNum');

        $num.val('').removeAttr('maxlength').removeAttr('disabled');

        switch(lttype){
            case 0:
                var d = new Date(),
                    s = d.Format('yyyy-MM-dd'),
                    v = g_info.LimitTime.Value,
                    val = '';
                if( v )
                    val = v.substr(0,4)+'-'+v.substr(4,2)+'-'+v.substr(6,2);
                else
                    val = s;
                $num.val(val);
                break;
            case 1:
                $num.attr({'maxlength':50});
                break;
            default :
                break;
        }
    });

    $('.LimitRangeTypeSet').change(function(){
        var _type = $(this).val(),
            $range= $LimitRange;
        if( _type == 1 )
            $range.val('').attr({'maxlength':512});
        else
            $range.val('');
    });

    $LimitRange.keypress(function(){
        var rangtype = parseInt($('.LimitRangeTypeSet').val());
        /*if( rangtype == 0){
            return false;
        }*/
    }).click(function(){
        showSetRange();
    });
}

/**
 *  收集填写的信息
 */
function gatherFileInfo(){
    var basis = $('#fBasis').val(),     //定密依据
        slevel= parseInt($('.fSlevelSel').val()), //秘密等级
        ltimetype = $('.LimitTimeTypeSet').val(), //保密期限类型
        ltimenum = $('#LimitTimeNum').val(),
        lRangeType = $('.LimitRangeTypeSet').val(),
        lRange = $('#LimitRange').val(),
        $IssueNum = $('#IssueNumber'),
        IssueNum = $IssueNum.val(),
        copySet = parseInt($('#copySet').val()),
        pasteSet = parseInt($('#pasteSet').val()),
        printSet = parseInt($('#printSet').val()),
        otherUnit = $('.multiselect').val(),
        res = false;

    while(true){
        if( !basis ){
            alert('请填写定密依据');
            break;
        } else if( !slevel ) {
            alert('请选择秘密等级');
            break;
        } else if( !ltimenum ) {
            alert('请填写保密期限');
            break;
        } else if( ltimenum.length > 50 ){
            alert('保密期限过长');
            break;
        } else if( !lRange ){
            alert('请填写知悉范围');
            break;
        } else if( lRange.length > 512 ) {
            alert('知悉范围过长');
            break;
        } else if( $IssueNum.length && !IssueNum ){
            alert('请填写文档号');
            break;
        }
        res = true;
        break;
    }

    if( res == false )
        return  res;

    res = {};
    $.extend( true, res, g_info );
    //其他定密单位数据收集
    for( var i in otherUnit ){
        for( var k in g_DefUnits ){
            if( otherUnit[i] == g_DefUnits[k].Id ){
                res.DefUnit.Other.push( g_DefUnits[k] );
                break;
            }
        }
    }
    res.DefBasis = basis;
    res.SecDegree= parseInt( slevel );
    res.LimitTime.Type = parseInt( ltimetype );
    res.LimitTime.Value = ltimenum;
    if( ltimetype == 0 ) {
        var _d = Date.parse(res.LimitTime.Value);
        res.LimitTime.Value = _d.Format('yyyyMMdd');
    }
    res.LimitRange.Type = parseInt( lRangeType );
    res.LimitRange.Value = lRange;
    if( $IssueNum.length )
        res.IssueNumber = IssueNum;
    if( g_optType == 4 ){
        res.OperationCtrl.copy  = copySet;
        res.OperationCtrl.paste = pasteSet;
        res.OperationCtrl.print = printSet;
    }

    return  res;
}

/**
 * 提交文件信息
 * @param args
 */
function setFileInfo( args ){
    if( !args )
        return  ;
    if( typeof JsObject != 'undefined' && JsObject.setFileSlevelInfo ){
        var ret = JsObject.setFileSlevelInfo( args );
        if( ret.error )
            alert( ret.error );
    }
}

function close(){
    if( typeof JsObject != 'undefined' && JsObject.closeWidget ){
        JsObject.closeWidget();
    }
}

function setinfo(){
    var res = gatherFileInfo();
    if( false != res )
        setFileInfo( res );
}

$(document).ready(function(){

    getInfos();

    var tmp = tmpl('main_tmpl'),
        rp_tmp,
        main_html;

    main_html = tmp( g_info );
    $('.main').html( main_html );

    if( g_optType == 1 ){
        $('textarea,input,select').attr('disabled','disabled');
    }

    InitEvent();

    $('.LimitTimeTypeSet').change();

    $('#fBasis').val( g_info.DefBasis );
    $('#LimitRange').val( g_info.LimitRange.Value );
    {
        var val = '',v = g_info.LimitTime.Value;
        switch ( g_info.LimitTime.Type ){
            case 0:
                val = v.substr(0,4)+'-'+v.substr(4,2)+'-'+v.substr(6,2);
                break;
            case 1:
                val = g_info.LimitTime.Value;
                break;
        }
        if( g_optType != 1 ) {
            $('#LimitTimeNum').val( val );
        } else {
            $('#LimitTimeNum').text( val );
        }
    }
});
