//主模块定义 模板
define(['jquery','jquery.layout','jquery.tmpl','ligerGrid'],function( jq, layout, tmpl ){
	var initHtml = '';

	var paneLayoutSettings = {
		name:						"mydocLayout"
	,	initPanes:					true // delay layout init until tab.show calls tabLayout.resizeAll()
	,	resizeWithWindow:			true // needed because 'nested' inside the tabLayout div
	,	spacing_open:				0
	,	spacing_closed:				0
	,	togglerLength_open:			0
	,	togglerLength_close:		0
	,	north__size:				'auto'
	,	south__size:				134
	,	center__onresize:			function(){
		var grid = curPage().pageObj.info.grid;
		if(grid)
			grid._onResize(grid);
		}
	};
	
	var page = function(param)
	{
		this.info = {	paneWrap	:	null,//记录包裹当前面板的jq对象
						grid_wrap	:	null,  //当前面板列表控件层对象
						grid		:	null,
						pane_layout :	null, //当前面板布局对象
						logtypes    :   {
                            0 : '全部',
                            1 : '密级文本操作记录',
                            2 : '密级标志操作记录',
                            3 : '密级工具操作记录'
                        },
                        opttypes    :   {
                            0  : '全部'         ,
                            1  : '新建密级文件'  ,
                            2  : '删除密级文件'  ,
                            3  : '重命名密级文件',
                            4  : '文件内容复制'  ,
                            5  : '文件打印'     ,
                            6  : '密级标志创建',
                            7  : '密级标志修改',
                            8  : '密级文件审核',
                            9  : '密级文件定密',
                            10 : '密级标志变更',
                            11 : '密级文件解密',
                            12 : '密级标志解除',
                            13 : '审计日志管理',
                            14 : '组织机构管理',
                            15 : '定密依据管理'
                        }
					};
		if(param)
		{
			this.info = $.extend( true, this.info,param );
		}
	};
	
	(function() {
        /**
         * 初始化
         * @param pagewrap
         */
		this.init = function(pagewrap){
			if( this.info.option.tmpl )
				this.info.tmpl = tmpl( this.info.option.tmpl );
			if( this.info.tmpl )
				initHtml = this.info.tmpl( this.info );
			this.info.paneWrap = $(pagewrap);
			pagewrap.html( initHtml );//初始化页面元素
			this.info.pane_layout = $(pagewrap).layout( paneLayoutSettings );
			this.info.grid_wrap   = this.info.paneWrap.find('.gridwrap');
            this.info.filepath    = this.info.paneWrap.find('.filepath');
            this.info.search      = this.info.paneWrap.find('.search');     //查询按钮
            this.info.logtypeSet  = this.info.paneWrap.find('.logtypeSet'); //日志类型设置
            this.info.opttypeSet  = this.info.paneWrap.find('.opttypeSet'); //文件操作类型
            this.info.stime = this.info.paneWrap.find('.stime');            //起始时间
            this.info.etime = this.info.paneWrap.find('.etime');            //终止时间
				
			this.initEvent();
		};

        /**
         * 页面显示回调
         * @param param
         */
		this.onshow = function( param ){//显示该模块
            if( !this.info.grid )
                this.list([]);

            var grid = this.info.grid;
            if(grid)
                grid._onResize(grid);
		};

        /**
         * 页面隐藏回调
         */
		this.onhide = function(){
		};

        /**
         * 页面销毁回调
         */
		this.ondestroy = function(){//销毁该模块页面元素
		};

        /**
         * 页面元素时间绑定
         */
		this.initEvent = function(){//模块事件初始化
			var cur_pane = this;

            this.info.stime.datepicker({
                dateFormat:'yy-mm-dd',
                onSelect: function( selectedDate ) {
                    var instance = $( this ).data( "datepicker" ),
                        date = $.datepicker.parseDate(
                                instance.settings.dateFormat ||
                                $.datepicker._defaults.dateFormat,
                            selectedDate, instance.settings );
                    cur_pane.info.etime.datepicker( "option", 'minDate', date );
                }
            });

            this.info.etime.datepicker({
                dateFormat:'yy-mm-dd',
                onSelect: function( selectedDate ) {
                    var instance = $( this ).data( "datepicker" ),
                        date = $.datepicker.parseDate(
                                instance.settings.dateFormat ||
                                $.datepicker._defaults.dateFormat,
                            selectedDate, instance.settings );
                    cur_pane.info.stime.datepicker( "option", 'maxDate', date );
                }
            });

            this.info.search.click(function(){
                var _info = {},
                    logtype = parseInt(cur_pane.info.logtypeSet.val()),
                    opttype = parseInt(cur_pane.info.opttypeSet.val()),
                    stime = cur_pane.info.stime.val(),
                    etime = cur_pane.info.etime.val();
                if( logtype )
                    _info.logtype = logtype;
                if( opttype )
                    _info.opttype = opttype;
                if( stime )
                    _info.stime = Math.floor( Date.parse(stime)/1000 );
                if( etime )
                    _info.etime = Math.floor( Date.parse(etime)/1000 );

                _info.searchtype = cur_pane.info.option.searchtype;

                cur_pane.search( _info );
            });

            this.info.paneWrap.find('.fileopt').click(function(){
                var func = $(this).attr('func');
                if( !func )
                    return  ;
                if( cur_pane[func] )
                    cur_pane[func]();
            });
		};

        /******************* 扩展接口 *********************/

        /**
         * 列表展现
         * @param data
         */
		this.list = function( data ){
            var cur_pane = this,
                showData = {Rows:[]};
            if( data )
                showData.Rows = data;

            if( !cur_pane.info.grid ){
                cur_pane.info.grid = cur_pane.info.grid_wrap.ligerGrid({
                    columns:[
                        {display: '描述信息', name: 'desc',       align:'left','width': '30%'},
                        {display: '用户名',   name: 'user',       align:'left','width': '10%'},
                        {display: '部门名称', name: 'department', align:'left','width': '10%'},
                        {display: '主机名',   name: 'host',       align:'left','width': '15%'},
                        {display: 'IP地址',   name: 'ip',         align:'left','width': '10%'},
                        {display: '日志时间', name: 'time',       align:'left','width': '15%'},
                        {display: '日志类别', name: 'type',       align:'left','width': '10%'}
                    ], pageSize: 30,usePager:true,pageSizeOptions: [10, 30, 50],rowHeight:25,checkbox:false,frozenCheckbox:false,frozen:true,selectRowButtonOnly:false,
                    data: showData,minColumnWidth:40,height:'100%',InWindow:false,headerRowHeight:25
                });
            } else {
                cur_pane.info.grid.options.newPage = 1;
                cur_pane.info.grid.loadData( showData );
            }
		};

        /**
         * 信息查询
         * @param args 查询条件
         * @returns {*}
         */
        this.search = function( args ){
            var res;
            if( !args || typeof JsObject == 'undefined' || !JsObject.fileSearch )
                return  ;

            res = JsObject.fileSearch( args );

            if( !res ){
                return  notify( 'error', '查询失败' );
            } else if( res.error ){
                return  notify( 'error', res.error );
            }
            if( res.files )
                this.list( res.files );
        };

        /**
         * 导出excel
         * @returns {*}
         */
        this.exportExcel = function(){
            if( typeof JsObject == 'undefined' || !JsObject.exportExcel )
                return  ;

            res = JsObject.exportExcel( {opttype:cur_pane.info.option.exporttype} );

            if( res.error ){
                return  notify( 'error', res.error );
            }
        };

        /**
         * 导出数据
         * @returns {*}
         */
        this.exportData = function(){
            if( typeof JsObject == 'undefined' || !JsObject.exportExcel )
                return  ;

            res = JsObject.exportData();

            if( res.error ){
                return  notify( 'error', res.error );
            }
        };

        /**
         * 导入数据
         * @returns {*}
         */
        this.importData = function(){
            if( typeof JsObject == 'undefined' || !JsObject.exportExcel )
                return  ;

            res = JsObject.importData();

            if( res.error ){
                return  notify( 'error', res.error );
            }
            if( res && res.files ){
                this.list( res.files );
            }
        };

	}).call(page.prototype);
	
	return	page;
})