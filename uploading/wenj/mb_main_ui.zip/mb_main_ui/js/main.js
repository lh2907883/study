//全局信息
var g_info = {
    pagesList:{
        '密标管理':[
            { label:'正式定密', iconclass:'menu_zsdm', pageid:'zsdm', pagemod:'docsign', img:'mb_icon_01.png', path:'密标管理 > 正式定密', option:{opttype:5, btn:[{label:'正式定密',cl:'zsdm'}]} },
            { label:'文件签发', iconclass:'menu_bzbg', pageid:'bzbg', pagemod:'docsign', img:'mb_icon_02.png', path:'密标管理 > 文件签发', option:{opttype:6, btn:[{label:'文件签发',cl:'bzbg'}]} },
            { label:'文件解密', iconclass:'menu_wjjm', pageid:'wjjm', pagemod:'docsign', img:'mb_icon_03.png', path:'密标管理 > 文件解密', option:{opttype:7, btn:[{label:'文件解密',cl:'wjjm'}]} },
            { label:'解除标志', iconclass:'menu_jcbz', pageid:'jcbz', pagemod:'docsign', img:'mb_icon_04.png', path:'密标管理 > 解除标志', option:{opttype:8, btn:[{label:'解除标志',cl:'jcbz'}], tmpl:'docunsign_pane_tmpl'} }
        ],
        '标志查询':[
            { label:'查询统计', iconclass:'menu_cxtj', pageid:'cxtj', pagemod:'cxtj_pane', img:'mb_icon_05.png', path:'标志查询 > 查询统计', option:{ opttype:9, searchtype:1, exporttype:1, btn:[{label:'导出Excel',cl:'a1'}], tmpl:'cxtj_pane_tmpl'} },
            { label:'解密提醒', iconclass:'menu_jmtx', pageid:'jmtx', pagemod:'jmtx_pane', img:'mb_icon_06.png', path:'标志查询 > 解密提醒', option:{ opttype:10, searchtype:2, exporttype:2, btn:[{label:'导出Excel',cl:'a1'}], tmpl:'jmtx_pane_tmpl'} }
        ],
        '日志查询':[
            { label:'审计查询', iconclass:'menu_sjcx', pageid:'sjcx', pagemod:'sjcx_pane', img:'mb_icon_07.png', path:'日志查询 > 审计查询', option:{ searchtype:3, exporttype:3, btn:[{label:'导出Excel',func:'exportExcel',cl:'a1'},{label:'导出数据',func:'exportData',cl:'b1'},{label:'导入数据',func:'importData',cl:'c1'}], tmpl:'sjcx_pane_tmpl'} },
            { label:'图形统计', iconclass:'menu_txtj', pageid:'txtj', pagemod:'txtj_pane', img:'mb_icon_08.png', path:'日志查询 > 图形统计', option:{ searchtype:4, tmpl:'txtj_pane_tmpl'} }
        ],
        '系统配置':[
            { label:'基础数据', iconclass:'menu_jcsj', pageid:'jcsj', pagemod:'jcsj_pane', img:'mb_icon_09.png', path:'系统配置 > 基础数据', option:{ tmpl:'jcsj_pane_tmpl'} }
        ]
    },
	pages:[]
};

//JS库配置
requirejs.config({
	baseUrl: "js",
	waitSeconds:20,
	paths: {
		'jquery':'./lib/jquery',
		'jquery-ui':'./lib/jquery-ui/ui/jquery-ui',
		'jquery.layout':'./lib/jquery.layout-latest',
		'jquery.tmpl':'./lib/jquery.tmpl',
        'liger-base':'./lib/ligerUI/js/core/base',
        'ligerGrid':'./lib/ligerUI/js/plugins/ligerGrid',
        'highchart':'./lib/highcharts.src'
	},
    shim: {
		'jquery-ui': {
            deps: ['jquery'],
            exports: 'jQuery-ui'
        },
        'jquery.layout': {
            deps: ['jquery','jquery-ui'],
            exports: 'jQuery.layout'
        },
		'jquery.tmpl': {
            deps: ['jquery'],
            exports: 'tmpl'
        },
        'liger-base': {
            deps: ['jquery'],
            exports: 'liger-base'
        },
        'ligerGrid': {
            deps: ['jquery','liger-base'],
            exports: 'liger-ligerGrid'
        }
    }
});

require(['jquery','jquery-ui','jquery.layout','notice','globalfun'],function(){
	$(document).ready(function(){
        init_title_bar();
        //getStructInfo();
		mainLayout();
	});
});
