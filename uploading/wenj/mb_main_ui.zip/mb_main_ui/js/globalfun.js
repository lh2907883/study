var data_loading = null;//数据加载时 显示的loading框
var g_Units,g_Users,g_StructInfo;
var slevels = ['','绝密','机密','秘密','内部','非密'],
    fileTypes = {
        1:'word文档',
        2:'excel文档',
        3:'ppt文档',
        4:'wps文字',
        5:'wps表格',
        6:'wps演示',
        7:'txt文本',
        8:'图片',
        9:'音频',
        10:'视频'
    },
    ManageStatus = ['','预定密','正式定密','文件签发','文件解密'];

function showDataLoading(){
    if(data_loading == null)
        data_loading = $('<div class="data_loading" id="data_loading"><div class="load_dw"><span class="logo_w"><img src="images/loading.gif" align="absmiddle"> 数据加载中...</span></div></div>').appendTo('body');
    data_loading.show();
}
//隐藏数据加载 遮蔽层
function hideDataLoading(){
    if(data_loading == null)
        data_loading = $('<div class="data_loading" id="data_loading"><div class="load_dw"><span class="logo_w"><img src="images/loading.gif" align="absmiddle"> 数据加载中...</span></div></div>').appendTo('body');
    data_loading.hide();
}


/**
 * 主体页面布局
 */
function mainLayout(){
    var options = {
        name:						    "mainLayout"
        ,	initPanes:					true // delay layout init until tab.show calls tabLayout.resizeAll()
        ,	resizeWithWindow:			true // needed because 'nested' inside the tabLayout div
        ,	spacing_open:				0
        ,	spacing_closed:				0
        ,	togglerLength_open:			0
        ,	togglerLength_close:		0
        ,	west__size:				    186//左边栏宽度; 左边栏定宽,右边自适应
        ,	west__resizable:			false
        ,	west__slidable:			    false
    };
    var home_sel_index = 0,index = 0,active_tab = -1;
    var page_group = [];

    g_info.mainlayout = $('.main_wrap').layout( options );

    if( g_info.pagesList ){
        for( var p in g_info.pagesList ){
            var page = g_info.pagesList[p],
                pgroup = { label:p, start:index, cl:'pagegroup_'+index};
            for( var sp in page ){
                var subpage = page[sp];

                if(p.selected == true && home_sel_index == 0)
                    home_sel_index = index;
                g_info.pages[subpage.pageid] = $.extend( subpage, addPageTab( subpage ) );
                g_info.pages[subpage.pageid].tabbtn.addClass( pgroup.cl );
                index++;
            }
            pgroup.len = index - pgroup.start;
            page_group.push( pgroup );
        }
    }

    if( home_sel_index == index - 1 )
        active_tab = 0;

    g_info.pagetabs = $(".main_wrap").tabs({active:active_tab,collapsible:false,
        activate:function(event,ui){
            if(ui.newTab.length == 0)//点击当前TAB页
                return	;

            var newpage   = ui.newTab.attr('tpage'),
                oldpage   = ui.oldTab.attr('tpage'),
                thisPage  = g_info.pages[newpage],
                js_module = thisPage.pagemod,
                prePage   = null;

            if( !newpage || !thisPage || !js_module )
                return	;
            if(ui.oldTab){
                g_info.pre_page = ui.oldTab.attr('tpage');//homePageList[ui.oldTab.attr('tpage')]
                prePage = g_info.pages[g_info.pre_page];//获取前一页面对象
            }
            g_info.cur_page = thisPage;

            if(prePage && prePage.pageObj && prePage.pageObj.onhide)//执行前一页面对象的hide接口
                prePage.pageObj.onhide();
            if(!thisPage.inited && js_module)//没有初始化的模块,执行初始化 ui.newTab.data('page_init')
            {
                require([js_module], function( tmp ) {//加载模块JS文件
                    thisPage.pageObj = new tmp(thisPage);

                    if(!thisPage.pageObj)
                        return	;

                    if($.isFunction(thisPage.pageObj.init))//执行模块初始化
                        thisPage.pageObj.init(thisPage.page,$.extend(thisPage,thisPage.initParam));

                    thisPage.inited = 1;//标识模块已初始化

                    if($.isFunction(thisPage.pageObj.onshow))//执行模块显示回调
                        thisPage.pageObj.onshow(thisPage.initParam);

                    if(thisPage.help && $.isFunction(thisPage.help))
                        thisPage.help();

                    thisPage.initParam = {};
                });
            }
            else
            {
                if( $.isFunction(thisPage.pageObj.onshow) )
                    thisPage.pageObj.onshow(thisPage.initParam);
                thisPage.initParam = {};
            }
        }
    });

    g_info.pagetabs.tabs('option','active',home_sel_index);

    for( var g in page_group){
        var group = page_group[g],
            $lis;

        $lis = $('.main_leftbar .'+group.cl);
        $lis.wrapAll( '<ul></ul>' );
        $( '<li>&nbsp;&nbsp;&nbsp;&nbsp;'+group.label+'</li>' ).insertBefore( $lis.parent('ul') );
    }
}

/**
 * 添加导航项
 */
function addPageTab( args )
{
    if( !args || !args.pageid )
        return  {};
    var tabbtn = $('<li class="pagelnkli" navpage="'+args.pageid+'"><img width="24" height="24" alt="" src="images/'+args.img+'"><a href="#'+args.pageid+'" onFocus="this.blur()" tpage="'+args.pageid+'" class="pagelnk '+args.iconclass+'">'+args.label+'</a></li>').appendTo('.main_leftbar');
    return {page:$('<div id="'+args.pageid+'" class="tabPanel homepage ui-layout-container" style="overflow:hidden;"></div>').appendTo('.main_center_pane'),tabbtn:tabbtn};
}

/**
 * 得到当前选择页对象
 * @returns {*}
 */
function curPage( ){
    return  g_info.cur_page;
}

function updateGrid( args ){
    var page = curPage();
    if( !page || !page.pageObj || !page.pageObj.updateItem )
        return  ;

    page.pageObj.updateItem( args );
}

/**
 * 窗口标题栏初始化
 */
function init_title_bar(){

    //禁止选中
    document.onselectstart = function() { return false; };

    $('*').disableSelection(function( event ){
        var target = $(event.target), ret = true;
        if( target.is('input')   ||
            target.is('select')  ||
            target.is('textarea')||
            target.is('button'))
            ret = false;
        return ret;
    });

    //禁止右键菜单
    document.oncontextmenu = function() { return false; };

    //禁止拖拽
    document.ondragstart = function() { return false; };

    //禁止复制
    document.oncopy = function() { return false; };

    //最小化
    $('.wnd_min').click(function(){
        if( typeof JsObject != 'undefined' )
            JsObject.showMin();
    });
    //最大化
    $('.wnd_max').click(function(){
        if($(this).hasClass('window_big2'))
            $(this).removeClass('window_big2').addClass('window_big');
        else
            $(this).removeClass('window_big').addClass('window_big2');
        if( typeof JsObject != 'undefined' )
            JsObject.showMax();
    });
    //关闭
    $('.wnd_close').click(function(){
        if( typeof JsObject != 'undefined' )
            JsObject.closeWidget();
    });
}
Date.prototype.Format = function (fmt) {
    var o = {
        "M+": this.getMonth() + 1, //月份        
        "d+": this.getDate(), //日        
        "h+": this.getHours(), //小时        
        "m+": this.getMinutes(), //分        
        "s+": this.getSeconds(), //秒        
        "q+": Math.floor((this.getMonth() + 3) / 3), //季度        
        "S": this.getMilliseconds() //毫秒    
    };
    if (/(y+)/.test(fmt))
        fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));

    for (var k in o)
        if (new RegExp("(" + k + ")").test(fmt))
            fmt = fmt.replace(RegExp.$1,  (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" +  o[k]).length)));
    return fmt;
};

function formatTime( nSecond ){
    var ret = '';
    if( !nSecond )
        return  ret;
    if( typeof nSecond == 'string' ){
        if( nSecond.indexOf(':') != -1 ){
            return  nSecond;
        } else {
            nSecond = parseInt( nSecond );
        }
    }
    if( typeof nSecond == 'number' ){
        var d = new Date( nSecond * 1000 );
        ret = d.Format('yyyy-MM-dd');
    }
    return ret;
}

function secToDays(sec)
{
    var day = 24*60*60,
        hours = 60*60,
        d = '',
        res = '';
    if(sec > day){
        d = Math.floor( Math.abs(sec) / day );
        res = d + ' 天';
    } else {
        res = '不足1天';
    }
    return res;
}

function getStructInfo(){
    if( g_StructInfo )
        return g_StructInfo;

    if( typeof JsObject != 'undefined' && JsObject.getStructInfo ){
        var _info = JsObject.getStructInfo();
        if( _info.error ) {
            alert(_info.error);
            return  false;
        }
        if( _info ){
            g_Units = _info.units;
            g_Users = _info.users;
            g_StructInfo = userStructDataHandle( g_Units, g_Users, userDFill );
         }
    }
    return g_StructInfo;
}

function userDFill(data,fid){
    var tmp = {};
    if( !data )
        return	;
    tmp.Id = data.Id;
    tmp.parentid = fid;
    tmp.Name = data.Name;
    return tmp;
}

//将组织架构,用户 组装成树型数据
function userStructDataHandle(data,chdData,filldata){
    function getchldData(tdata){
        for(var key in chdData)
        {
            var d = chdData[key];
            if(chdData[key].pid == tdata.Id)
            {
                if(filldata)
                    tdata.children.push(filldata(d,tdata.Id));
            }
        }
    }

    function RecurFunc(tempData){
        var parentId;
        if(tempData == undefined)
        {
            parentId = '0';
            tempData = [];
        } else {
            parentId = tempData.id;
        }
        for(key in data)
        {
            var tdata = {};
            if(data[key].parentid == parentId)
            {
                tdata.Id = data[key].Id;
                tdata.Name = data[key].Name;
                tdata.parentid = parentId;
                tdata.children = [];
                RecurFunc(tdata);
                getchldData(tdata);
                tempData.push(tdata);
            }
        }
        return tempData;
    }
    var rawdata = {
        identifier: 'Id',
        label: 'Name',
        items: []
    };

    return RecurFunc();
}

function getUserName(uid)
{
    var userData = g_Users;
    if( !userData )
        return  '';
    for(var k in userData)
    {
        if(userData[k].Id == uid)
            return userData[k].Name;
    }

    var struct = g_Units;
    if( !struct )
        return  '';
    for(var k in struct)
    {
        if(struct[k].Id == uid)
            return struct[k].Name;
    }
    return	'';
}