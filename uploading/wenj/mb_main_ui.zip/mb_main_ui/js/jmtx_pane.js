//主模块定义 模板
define(['jquery','jquery.layout','jquery.tmpl','ligerGrid'],function( jq, layout, tmpl ){
	var initHtml = '';

	var paneLayoutSettings = {
		name:						"mydocLayout"
	,	initPanes:					true // delay layout init until tab.show calls tabLayout.resizeAll()
	,	resizeWithWindow:			true // needed because 'nested' inside the tabLayout div
	,	spacing_open:				0
	,	spacing_closed:				0
	,	togglerLength_open:			0
	,	togglerLength_close:		0
	,	north__size:				'auto'
	,	south__size:				134
	,	center__onresize:			function(){
		var grid = curPage().pageObj.info.grid;
		if(grid)
			grid._onResize(grid);
		}
	};
	
	var page = function(param)
	{
		this.info = {	paneWrap	:	null,//记录包裹当前面板的jq对象
						grid_wrap	:	null,  //当前面板列表控件层对象
						grid		:	null,
						pane_layout :	null, //当前面板布局对象
						option		:	{
							tmpl : 'docsign_pane_tmpl'
						}
					};
		if(param)
		{
			this.info = $.extend( true, this.info,param );
		}
	};
	
	(function() {
        /**
         * 初始化
         * @param pagewrap
         */
		this.init = function(pagewrap){
			if( this.info.option.tmpl )
				this.info.tmpl = tmpl( this.info.option.tmpl );
			if( this.info.tmpl )
				initHtml = this.info.tmpl( this.info );
			this.info.paneWrap = $(pagewrap);
			pagewrap.html( initHtml );//初始化页面元素
			this.info.pane_layout = $(pagewrap).layout( paneLayoutSettings );
			this.info.grid_wrap = this.info.paneWrap.find('.gridwrap');
            this.info.filepath = this.info.paneWrap.find('.filepath');
            this.info.browse = this.info.paneWrap.find('.browse');
            this.info.slevelset = this.info.paneWrap.find('.fSlevelSet'); //秘密等级
            this.info.ftypeset = this.info.paneWrap.find('.fileTypeSet'); //文档类型
            this.info.unit = this.info.paneWrap.find('.unit');            //定密单位
            this.info.ustime = this.info.paneWrap.find('.unsigntime');    //解密时间
            this.info.ltime = this.info.paneWrap.find('.ltime');          //保密期限
            this.info.person = this.info.paneWrap.find('.defPerson');     //定密人员
            this.info.stime = this.info.paneWrap.find('.stime');          //定密起始时间
            this.info.etime = this.info.paneWrap.find('.etime');          //定密终止时间
            this.info.alldisk = this.info.paneWrap.find('.alldisk');      //是否全盘搜索
            this.info.search = this.info.paneWrap.find('.search');
				
			this.initEvent();
		};

        /**
         * 页面显示回调
         * @param param
         */
		this.onshow = function( param ){//显示该模块
            if( !this.info.grid )
                this.list([]);

            var grid = this.info.grid;
            if(grid)
                grid._onResize(grid);
		};

        /**
         * 页面隐藏回调
         */
		this.onhide = function(){
		};

        /**
         * 页面销毁回调
         */
		this.ondestroy = function(){//销毁该模块页面元素
		};

        /**
         * 页面元素时间绑定
         */
		this.initEvent = function(){//模块事件初始化
			var cur_pane = this;

            this.info.stime.datepicker({
                dateFormat:'yy-mm-dd',
                onSelect: function( selectedDate ) {
                    var instance = $( this ).data( "datepicker" ),
                        date = $.datepicker.parseDate(
                                instance.settings.dateFormat ||
                                $.datepicker._defaults.dateFormat,
                            selectedDate, instance.settings );
                    cur_pane.info.etime.datepicker( "option", 'minDate', date );
                }
            });

            this.info.etime.datepicker({
                dateFormat:'yy-mm-dd',
                onSelect: function( selectedDate ) {
                    var instance = $( this ).data( "datepicker" ),
                        date = $.datepicker.parseDate(
                                instance.settings.dateFormat ||
                                $.datepicker._defaults.dateFormat,
                            selectedDate, instance.settings );
                    cur_pane.info.stime.datepicker( "option", 'maxDate', date );
                }
            });

            this.info.browse.click(function(){
                if($(this).hasClass('disabled'))
                    return	;
                cur_pane.fileBrowse();
            });

            this.info.search.click(function(){
                var _info = {},
                    slevel = parseInt(cur_pane.info.slevelset.val()),
                    ftype = parseInt(cur_pane.info.ftypeset.val()),
                    unit = cur_pane.info.unit.val(),
                    dectime = parseInt(cur_pane.info.ustime.val()),
                    ltime = cur_pane.info.ltime.val(),
                    person = cur_pane.info.person.val(),
                    stime = cur_pane.info.stime.val(),
                    etime = cur_pane.info.etime.val();
                _info.dir = cur_pane.info.filepath.val();
                if( slevel )
                    _info.degree = slevel;
                if( ftype )
                    _info.filetype = ftype;
                if( unit )
                    _info.unit = unit;
                if( dectime )
                    _info.dectime = dectime;
                if( ltime )
                    _info.limittime = ltime;
                if( person )
                    _info.person = person;
                if( stime )
                    _info.stime = Math.floor( Date.parse(stime)/1000 );
                if( etime )
                    _info.etime = Math.floor( Date.parse(etime)/1000 );

                if( !_info.dir )
                    return  notify('wran','请选择查询路径');

                _info.searchtype = cur_pane.info.option.searchtype;

                cur_pane.search( _info );
            });

            this.info.fileoptBtn = this.info.paneWrap.find('.fileopt').click(function(){
                var res;
                if( typeof JsObject == 'undefined' || !JsObject.exportExcel )
                    return  ;

                res = JsObject.exportExcel( {opttype:cur_pane.info.option.exporttype} );

                if( res.error ){
                    return  notify( 'error', res.error );
                }
            });
		};

        /******************* 扩展接口 *********************/

        /**
         * 浏览选择文件
         * @param args
         * {
         *  dirflag  0:file; 1:dir
         *  subdir	,0:不包含子文件夹;1:包含子文件夹
         *  opttype  1:查看密级;2:修改密级;3:文件审核4:正式定密;5:标志变更;6:文件解密;7:解除标志;
         * }
         * return   {
         *              dir:'',  用户选择路径
         *              fileinfo:[
         *                  {
         *                      path:,  文件全路径
         *                      date:,  标密时间
         *                      state:  状态
         *                  }, ...
         *              ]
         *          }
         */
        this.fileBrowse = function(){
            var res;
            if( typeof JsObject == 'undefined' || !JsObject.fileBrowse )
                return  ;

            res = JsObject.fileBrowse( {dirflag:1,subdir:1,opttype:this.info.option.opttype} );

            if( !res ){
                return  notify( 'error', '获取文件失败' );
            } else if( res.error ){
                return  notify( 'error', res.error );
            }
            if( res.dir )
                this.info.filepath.val( res.dir );
        };

        /**
         * 文件查询
         * @param args
         * @returns {*}
         */
        this.search = function( args ){
            var res;
            if( !args || typeof JsObject == 'undefined' || !JsObject.fileSearch )
                return  ;

            res = JsObject.fileSearch( args );

            if( !res ){
                return  notify( 'error', '查询失败' );
            } else if( res.error ){
                return  notify( 'error', res.error );
            }
            if( res.files )
                this.list( res.files );
        };

        /**
         *
         * @param data
         */
        this.list = function( data ){
            var cur_pane = this,
                showData = {Rows:[]};
            if( data )
                showData.Rows = data;

            if( !cur_pane.info.grid ){
                cur_pane.info.grid = cur_pane.info.grid_wrap.ligerGrid({
                    columns:[
                        {display: '文件路径', name: 'path', align:'left','width': '16%'},
                        {display: '到期时间', name: 'endtime', align:'left','width': '10%',render:function(rowData, rowindex, value){
                            if( value )
                                return  formatTime( value );
                        }},
                        {display: '剩余时间', name: 'lefttime', align:'left','width': '10%',render:function(rowData, rowindex, value){
                            if( value >= 0 )
                                return  '还剩' + secToDays( value );
                            else
                                return  '已过期' + secToDays( value );
                        }},
                        {display: '密级等级', name: 'SecDegree', align:'left','width': '10%',render:function(rowData, rowindex, value){
                            if( value && slevels[value] )
                                return slevels[value];
                        }},
                        {display: '保密期限', name: 'LimitTime', align:'left','width': '10%',render:function(rowData, rowindex, value){
                            var val = rowData.LimitTime.Value,ret = '';
                            if( rowData.LimitTime.Type == 0 ){
                                ret = val.substr(0,4)+'-'+val.substr(4,2)+'-'+val.substr(6,2);
                            } else {
                                ret = val;
                            }
                            return  val;
                        }},
                        //{display: '定密人员', name: 'person', align:'left','width': '6%'},
                        {display: '定密时间', name: 'LimitTime', align:'left','width': '9%',render:function(rowData, rowindex, value){
                            var val = rowData.LimitTime.DefTime;
                            return  ret = val.substr(0,4)+'-'+val.substr(4,2)+'-'+val.substr(6,2)+' '+val.substr(8,2)+':'+val.substr(10,2)+':'+val.substr(12,2);
                        }},
                        {display: '定密单位', name: 'DefUnit', align:'left','width': '9%',render:function(rowData, rowindex, value){
                            return  rowData.DefUnit.Main.Name;
                        }},
                        {display: '知悉范围', name: 'LimitRange', align:'left','width': '10%',render:function(rowData, rowindex, value){
                            var ret = '',val = rowData.LimitRange.Value;
                            if( rowData.LimitRange.Type == 0 ){
                                for( var i in val ){
                                    if( !val[i].Name )
                                        continue;
                                    //getUserName(val[i].Id);
                                    if( i != 0 )
                                        ret += ',';
                                    ret += val[i].Name;
                                }
                            } else {
                                ret = val;
                            }
                            return  ret;
                        }},
                        {display: '定密依据', name: 'DefBasis', align:'left','width': '10%'}
                    ], pageSize: 30,usePager:true,pageSizeOptions: [10, 30, 50],rowHeight:25,checkbox:false,frozenCheckbox:false,frozen:true,selectRowButtonOnly:false,
                    data: showData,minColumnWidth:40,height:'100%',InWindow:false,headerRowHeight:25
                });
            } else {
                cur_pane.info.grid.options.newPage = 1;
                cur_pane.info.grid.loadData( showData );
            }
        };


	}).call(page.prototype);
	
	return	page;
})