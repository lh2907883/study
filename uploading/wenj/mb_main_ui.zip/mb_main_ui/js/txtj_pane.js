//主模块定义 模板
define(['jquery','jquery.layout','jquery.tmpl','ligerGrid','highchart'],function( jq, layout, tmpl ){
	var initHtml = '';

	var paneLayoutSettings = {
		name:						"mydocLayout"
	,	initPanes:					true // delay layout init until tab.show calls tabLayout.resizeAll()
	,	resizeWithWindow:			true // needed because 'nested' inside the tabLayout div
	,	spacing_open:				0
	,	spacing_closed:				0
	,	togglerLength_open:			0
	,	togglerLength_close:		0
	,	north__size:				'auto'
	,	south__size:				134
	,	center__onresize:			function(){
            var resize = curPage().pageObj.resize;
            if( resize )
                resize();
		}
	};
	
	var page = function(param)
	{
		this.info = {	paneWrap	:	null,//记录包裹当前面板的jq对象
						grid_wrap	:	null,  //当前面板列表控件层对象
						grid		:	null,
						pane_layout :	null, //当前面板布局对象
						chart_x     :   [
                            '密级文件新建',
                            '密级文件删除',
                            '密级文件解密',
                            '密级标志创建',
                            '密级标志修改',
                            '密级标志解除'
                        ]
					};
		if(param)
		{
			this.info = $.extend( true, this.info,param );
		}
	};
	
	(function() {
        /**
         * 初始化
         * @param pagewrap
         */
		this.init = function(pagewrap){
			if( this.info.option.tmpl )
				this.info.tmpl = tmpl( this.info.option.tmpl );
			if( this.info.tmpl )
				initHtml = this.info.tmpl( this.info );
			this.info.paneWrap = $(pagewrap);
			pagewrap.html( initHtml );//初始化页面元素
			this.info.pane_layout = $(pagewrap).layout( paneLayoutSettings );
			this.info.grid_wrap = this.info.paneWrap.find('.gridwrap');
            this.info.filepath = this.info.paneWrap.find('.filepath');
            this.info.stime = this.info.paneWrap.find('.stime');          //起始时间
            this.info.etime = this.info.paneWrap.find('.etime');          //终止时间
            this.info.chartwrap = this.info.paneWrap.find('.chartwrap');
            this.info.search = this.info.paneWrap.find('.search');

			this.initEvent();
            this.bldChart();
		};

        this.resize = function(){
            var cur_pane = curPage().pageObj;
            if( cur_pane.info.chartwrap.is(':visible') ){
                if( cur_pane.info.chart )
                    cur_pane.info.chart.reflow();
            }
        };

        /**
         * 页面显示回调
         * @param param
         */
		this.onshow = function( param ){
            this.resize();
        };

        /**
         * 页面隐藏回调
         */
		this.onhide = function(){};

        /**
         * 页面销毁回调
         */
		this.ondestroy = function(){};

        /**
         * 页面元素时间绑定
         */
		this.initEvent = function(){//模块事件初始化
			var cur_pane = this;

            this.info.stime.datepicker({
                dateFormat:'yy-mm-dd',
                onSelect: function( selectedDate ) {
                    var instance = $( this ).data( "datepicker" ),
                        date = $.datepicker.parseDate(
                                instance.settings.dateFormat ||
                                $.datepicker._defaults.dateFormat,
                            selectedDate, instance.settings );
                    cur_pane.info.etime.datepicker( "option", 'minDate', date );
                }
            });

            this.info.etime.datepicker({
                dateFormat:'yy-mm-dd',
                onSelect: function( selectedDate ) {
                    var instance = $( this ).data( "datepicker" ),
                        date = $.datepicker.parseDate(
                                instance.settings.dateFormat ||
                                $.datepicker._defaults.dateFormat,
                            selectedDate, instance.settings );
                    cur_pane.info.stime.datepicker( "option", 'maxDate', date );
                }
            });

            this.info.search.click(function(){
                var _info = {},
                    stime = cur_pane.info.stime.val(),
                    etime = cur_pane.info.etime.val();
                if( stime )
                    _info.stime = Math.floor( Date.parse(stime)/1000 );
                if( etime )
                    _info.etime = Math.floor( Date.parse(etime)/1000 );

                _info.searchtype = cur_pane.info.option.searchtype;

                cur_pane.search( _info );
            });
		};

        /******************* 扩展接口 *********************/

        /**
         * 信息查询
         * @param args 查询条件
         * @returns {*}
         */
        this.search = function( args ){
            var res;
            if( !args || typeof JsObject == 'undefined' || !JsObject.fileSearch )
                return  ;

            res = JsObject.fileSearch( args );

            if( !res ){
                return  notify( 'error', '查询失败' );
            } else if( res.error ){
                return  notify( 'error', res.error );
            }
            if( res.info )
                this.bldChart( res.info );
        };

        /**
         * 报表展现
         * @param data
         */
        this.bldChart = function( data ){
            var col_y = [];

            var colors = Highcharts.getOptions().colors;

            for(var i=0;i<this.info.chart_x.length;i++){
                col_y.push({y: 0,color: colors[i]});
            }

            for(var k in data){
                var log = data[k];
                if( log.opttype && col_y[log.opttype] != undefined ){
                    col_y[log.opttype] += 1;
                }
            }

            if( this.info.chart ){
                this.info.chart.series[0].setData( col_y );
            } else {
                this.info.chart = this.info.chartwrap.highcharts({
                    chart: { type: 'column' },
                    title: { text: ''},
                    xAxis: { categories: this.info.chart_x},
                    yAxis: { title: {text: '操作次数'},min:0},
                    tooltip: { pointFormat: '{point.y} 次'},
                    series: [{
                        name:'文档操作',
                        data: col_y,
                        color: 'white',
                        xAxis:0,
                        yAxis:0
                    }]
                }).highcharts();
            }
        };
	}).call(page.prototype);
	
	return	page;
})