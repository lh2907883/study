//主模块定义 模板
define(['jquery','jquery.layout','jquery.tmpl','ligerGrid'],function( jq, layout, tmpl ){
	var initHtml = '';

	var paneLayoutSettings = {
		name:						"mydocLayout"
	,	initPanes:					true // delay layout init until tab.show calls tabLayout.resizeAll()
	,	resizeWithWindow:			true // needed because 'nested' inside the tabLayout div
	,	spacing_open:				0
	,	spacing_closed:				0
	,	togglerLength_open:			0
	,	togglerLength_close:		0
	,	north__size:				'auto'
	,	south__size:				40
	,	center__onresize:			function(){
		var grid = curPage().pageObj.info.grid;
		if(grid)
			grid._onResize(grid);
		}
	};
	
	var page = function(param)
	{
		this.info = {	paneWrap	:	null,//记录包裹当前面板的jq对象
						grid_wrap	:	null,  //当前面板列表控件层对象
						grid		:	null,
						pane_layout :	null, //当前面板布局对象
                        unitID      :	'',//单位编号
                        unitName    :   '',//单位名称
                        departID    :   '',//部门编号
                        departName  :   '',//部门名称
                        userID      :   '',//用户编号
                        userName    :   '',//用户名称
                        userSlevel  :   '',//用户密级
                        hostCode    :   '',//主机码
                        userRole    :   ''//用户角色
					};
		if(param)
		{
			this.info = $.extend( true, this.info,param );
		}
	};
	
	(function() {
        /**
         * 初始化
         * @param pagewrap
         */
		this.init = function(pagewrap){
			if( this.info.option.tmpl )
				this.info.tmpl = tmpl( this.info.option.tmpl );
			if( this.info.tmpl )
				initHtml = this.info.tmpl($.extend(this.info,this.getBaseInfos()) );
			this.info.paneWrap = $(pagewrap);
			pagewrap.html( initHtml );//初始化页面元素
			this.info.pane_layout = $(pagewrap).layout( paneLayoutSettings );
				
			this.initEvent();
		};

        /**
         * 页面显示回调
         * @param param
         */
		this.onshow = function( param ){};

        /**
         * 页面隐藏回调
         */
		this.onhide = function(){};

        /**
         * 页面销毁回调
         */
		this.ondestroy = function(){};

        /**
         * 页面元素时间绑定
         */
		this.initEvent = function(){//模块事件初始化
			var cur_pane = this;

            this.info.paneWrap.find('.importBasis').click(function(){
                if( typeof JsObject == 'undefined' || !JsObject.importBasis )
                    return  ;

                res = JsObject.importBasis();

                if( res == 0 )
                    return  notify('success','导入成功');
                if( res && res.error ){
                    return  notify( 'error', res.error );
                }

            });

            this.info.paneWrap.find('.importUsers').click(function(){
                if( typeof JsObject == 'undefined' || !JsObject.importUsers )
                    return  ;

                res = JsObject.importUsers();

                if( res == 0 )
                    return  notify('success','导入成功');
                if( res && res.error ){
                    return  notify( 'error', res.error );
                }
            });
		};

        /******************* 扩展接口 *********************/
        this.getBaseInfos = function(){
            if( typeof JsObject == 'undefined' || !JsObject.getBaseInfos )
                return  {};

            res = JsObject.getBaseInfos();

            if( res && res.error ){
                notify( 'error', res.error );
                return  {};
            }
            if( res && res.info ){
                return res.info;
            }
        };

	}).call(page.prototype);
	
	return	page;
})