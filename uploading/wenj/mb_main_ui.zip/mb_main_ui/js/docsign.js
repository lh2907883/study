//主模块定义 模板
define(['jquery','jquery.layout','jquery.tmpl','ligerGrid'],function( jq, layout, tmpl ){
	var initHtml = '';

	var paneLayoutSettings = {
		name:						"mydocLayout"
	,	initPanes:					true // delay layout init until tab.show calls tabLayout.resizeAll()
	,	resizeWithWindow:			true // needed because 'nested' inside the tabLayout div
	,	spacing_open:				0
	,	spacing_closed:				0
	,	togglerLength_open:			0
	,	togglerLength_close:		0
	,	north__size:				'auto'
	,	south__size:				134
	,	center__onresize:			function(){
		var grid = curPage().pageObj.info.grid;
		if(grid)
			grid._onResize(grid);
		}
	};
	
	var page = function(param)
	{
		this.info = {	paneWrap	:	null,//记录包裹当前面板的jq对象
						grid_wrap	:	null,  //当前面板列表控件层对象
						grid		:	null,
						pane_layout :	null, //当前面板布局对象
						option		:	{
							tmpl : 'docsign_pane_tmpl'
						}
					};
		if(param)
		{
			this.info = $.extend( true, this.info,param );
		}
	};
	
	(function() {
        /**
         * 初始化
         * @param pagewrap
         */
		this.init = function(pagewrap){
			if( this.info.option.tmpl )
				this.info.tmpl = tmpl( this.info.option.tmpl );
			if( this.info.tmpl )
				initHtml = this.info.tmpl( this.info );
			this.info.paneWrap = $(pagewrap);
			pagewrap.html( initHtml );//初始化页面元素
			this.info.pane_layout = $(pagewrap).layout( paneLayoutSettings );
			this.info.grid_wrap = this.info.paneWrap.find('.gridwrap');
            this.info.filepath = this.info.paneWrap.find('.filepath');
            this.info.outtypeset = this.info.paneWrap.find('.outtype_set');
            this.info.outpath = this.info.paneWrap.find('.outpath');
            this.info.setoutpath = this.info.paneWrap.find('.setOutPath');
            this.info.getfiletype = 0;
				
			this.initEvent();
		};

        /**
         * 页面显示回调
         * @param param
         */
		this.onshow = function( param ){//显示该模块
            if( !this.info.grid )
                this.list([]);

            var grid = this.info.grid;
            if(grid)
                grid._onResize(grid);
		};

        /**
         * 页面隐藏回调
         */
		this.onhide = function(){
		};

        /**
         * 页面销毁回调
         */
		this.ondestroy = function(){//销毁该模块页面元素
		};

        /**
         * 页面元素时间绑定
         */
		this.initEvent = function(){//模块事件初始化
			var cur_pane = this;

            this.info.paneWrap.find('.browse').click(function(){
                if($(this).hasClass('disabled'))
                    return	;

                var param = { opttype:cur_pane.info.option.opttype };
                param.dirflag = cur_pane.info.getfiletype;
                if( param.dirflag == 1 ){
                    param.subdir = cur_pane.info.paneWrap.find('.subdir').is(':checked')?1:0;
                }
                cur_pane.fileBrowse( param );
            });

            this.info.outtypeset.click(function(){
                var val = $(this).attr('outtype');
                if( val == 3 ){
                    cur_pane.info.setoutpath.show();
                    cur_pane.info.outpath.show();
                } else {
                    cur_pane.info.setoutpath.hide();
                    cur_pane.info.outpath.val('').hide();
                }
            });

            this.info.setoutpath.click(function(){
                if( typeof JsObject == 'undefined' || !JsObject.outPathSet )
                    return  ;
                var ret = JsObject.outPathSet();
                if( !ret ){
                    return  notify( 'error', '设置路径失败' );
                } else if( ret.error ){
                    return  notify( 'error', ret.error );
                }
                if( ret.path )
                    cur_pane.info.outpath.val( ret.path );
            });

            this.info.paneWrap.find('.getfiletype').change(function(){
                cur_pane.info.getfiletype = parseInt( $(this).val() );
                if( cur_pane.info.getfiletype == 1 ){
                    cur_pane.info.paneWrap.find('.subdir_wrap').show();
                } else {
                    cur_pane.info.paneWrap.find('.subdir_wrap').hide();
                }
            });

            this.info.fileoptBtn = this.info.paneWrap.find('.fileopt').click(function(){
                var item = cur_pane.info.grid.getSelected(), param = {};
                if( !item )
                    return  notify('warn','请选择文件');
                param.file = [{path:item.path}];
                param.opttype = cur_pane.info.option.opttype;
                if( cur_pane.info.outtypeset.length ){
                    param.outsetting = parseInt( cur_pane.info.paneWrap.find('[name="outtype_set"]:checked').attr('outtype') );
                    param.outpath = cur_pane.info.outpath.val();
                }
                cur_pane.fileopt( param );
            });
		};

        /******************* 扩展接口 *********************/

        /**
         * 浏览选择文件
         * @param args
         * {
         *  dirflag  0:file; 1:dir
         *  subdir	,0:不包含子文件夹;1:包含子文件夹
         *  opttype  1:查看密级;2:修改密级;3:文件审核4:正式定密;5:标志变更;6:文件解密;7:解除标志;
         * }
         * return   {
         *              dir:'',  用户选择路径
         *              fileinfo:[
         *                  {
         *                      path:,  文件全路径
         *                      date:,  标密时间
         *                      state:  状态
         *                  }, ...
         *              ]
         *          }
         */
        this.fileBrowse = function( args ){
            var res;
            if( typeof JsObject == 'undefined' )
                return  ;

            showDataLoading();
            res = JsObject.fileBrowse( args );
            hideDataLoading();

            if( !res ){
                return  notify( 'error', '获取文件失败' );
            } else if( res.error ){
                return  notify( 'error', res.error );
            }
            if( res.dir )
                this.info.filepath.val( res.dir );
            if( res.fileinfo )
                this.list( res.fileinfo );
        };

        /**
         * 文件操作(文件审核,正式定密,标志变更,文件解密,解除标志)
         * @param args
         */
        this.fileopt = function( args ){
            var ret;
            if( !args || typeof JsObject == 'undefined' )
                return  ;
            ret = JsObject.operateFile( args );
            if( ret && ret.error )
                notify( 'error',ret.error );
        };

        /**
         *
         * @param data
         */
		this.list = function( data ){
            var cur_pane = this,
                showData = {Rows:[]};
            if( data )
                showData.Rows = data;

            if( !cur_pane.info.grid ){
                cur_pane.info.grid = cur_pane.info.grid_wrap.ligerGrid({
                    columns:[
                        {display: '文件路径', name: 'path', align:'left','width': '45%'},
                        {display: '定密时间', name: 'path', align:'left','width': '20%',type:'int',render:function(rowData, rowindex, value){
                            return  formatTime( rowData.LimitTime.DefTime );
                        }},
                        {display: '管理状态', name: 'ManageStatus', align:'left','width': '20%',render:function(rowData, rowindex, value){
                            return  ManageStatus[value];
                        }},
                        {display: '操作',     name: 'result', align:'left','width': '15%'}
                    ], pageSize: 30,usePager:true,pageSizeOptions: [10, 30, 50],rowHeight:25,checkbox:false,frozenCheckbox:false,frozen:true,selectRowButtonOnly:false,
                    data: showData,minColumnWidth:40,height:'100%',InWindow:false,headerRowHeight:25,
                    onSelectRow: function( data ){
                        var row = cur_pane.info.grid.getSelected();
                        if( row ){
                            cur_pane.info.fileoptBtn.removeClass('disabled');
                        } else {
                            cur_pane.info.fileoptBtn.addClass('disabled');
                        }
                    },
                    onUnSelectRow: function( data ) {
                        var row = cur_pane.info.grid.getSelected();
                        if( row ){
                            cur_pane.info.fileoptBtn.removeClass('disabled');
                        } else {
                            cur_pane.info.fileoptBtn.addClass('disabled');
                        }
                    }
                });
            } else {
                cur_pane.info.grid.options.newPage = 1;
                cur_pane.info.grid.loadData( showData );
		alert(showData);
            }
		};

        /**
         * 更新数据
         * @param args
         */
        this.updateItem = function( args ){
            if( !args || !args.file || !this.info.grid )
                return  ;
            var grid = this.info.grid,
                data = this.info.grid.rows;
            for( var r in data ){
                var row = data[r];
                for( var f in args.file ){
                    var file = args.file[f];
                    if( file.path == row.path ){
                        grid.updateRow( row, { result:file.result } );
                    }
                }
            }
        };

	}).call(page.prototype);
	
	return	page;
})
